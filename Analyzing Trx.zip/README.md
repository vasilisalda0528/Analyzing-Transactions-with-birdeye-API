### Scripts

#### `npm start`
compile index.ts to index.js
#### `npm build`
compile index.ts to index.js in build folder
